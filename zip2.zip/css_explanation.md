# Understanding CSS Configuration in Your Cybernack Next.js Website

This guide explains how CSS, specifically Tailwind CSS, is configured and works within the Next.js project structure provided for your Cybernack website. Understanding this will help troubleshoot issues like the missing CSS you encountered during your initial Vercel deployment attempt.

## 1. Tailwind CSS Integration

Your website uses **Tailwind CSS**, a utility-first CSS framework. Instead of writing custom CSS rules, you primarily use pre-defined utility classes directly in your HTML/JSX markup.

Key configuration files for Tailwind:

*   **`tailwind.config.js`**: This file is crucial. It tells Tailwind:
    *   Where to look for utility classes being used (the `content` array should include paths to your pages and components: `./src/**/*.{js,ts,jsx,tsx,mdx}`).
    *   How to customize the theme (colors, fonts, spacing, etc.). The file I provided (`/home/ubuntu/cybernack-recreated-files/tailwind.config.js`) includes the light theme color palette we discussed.
    *   Any plugins to use (none are used in this basic setup).
*   **`postcss.config.js`**: (Implicitly handled by Next.js) Next.js automatically configures PostCSS (a tool for transforming CSS with JavaScript) to process Tailwind CSS. You typically don't need to create this file manually in a standard Next.js setup.

## 2. The Role of `globals.css`

The file `/home/ubuntu/cybernack-recreated-files/src/app/globals.css` is the main global stylesheet for your application. It serves several purposes:

*   **Importing Tailwind Directives**: The lines `@tailwind base;`, `@tailwind components;`, and `@tailwind utilities;` are essential. They inject Tailwind's base styles, component classes, and utility classes into your CSS.
*   **Defining Base Styles**: The `@layer base { ... }` section allows you to define custom base styles for HTML elements (like `body`, `h1`, etc.) or set up CSS variables (like `--background`, `--foreground` used for the light theme).
*   **Defining Custom Component Classes**: The `@layer components { ... }` section allows you to create reusable custom component classes using Tailwind's `@apply` directive (e.g., `.btn`, `.btn-primary`). This helps keep your JSX cleaner.

**Crucially, this `globals.css` file must be imported into your root layout file (`/home/ubuntu/cybernack-recreated-files/src/app/layout.tsx`) for the styles to be applied globally.** The `layout.tsx` file I provided already includes `import "./globals.css";`.

## 3. How Styles are Applied

*   **Utility Classes**: Most styling is done by adding Tailwind utility classes directly to elements in your `.tsx` component files (e.g., `<div className="bg-primary text-primary-foreground p-4 rounded-lg">`).
*   **Global Styles**: Base styles and custom component classes defined in `globals.css` are applied automatically.

## 4. The Build Process (`npm run build`)

When Vercel (or you locally) runs `npm run build`:

1.  Tailwind scans all the files specified in `tailwind.config.js` (`content` array).
2.  It identifies all the Tailwind utility classes you've used.
3.  It generates a CSS file containing *only* the styles corresponding to the classes you've actually used, plus the base styles and component styles from `globals.css`.
4.  Next.js optimizes and includes this generated CSS in the final build output (`.next` directory).

This process ensures your final CSS is highly optimized and small.

## 5. Why Copying CSS Manually Doesn't Work Well

Manually copying the *output* CSS from the live site (`https://zmpwknzl.manus.space/`) into your `globals.css` file is not the correct approach because:

*   It bypasses the Tailwind build process.
*   The copied CSS might be very large and include styles you don't actually need.
*   It makes it impossible to modify styles easily using utility classes later.
*   It likely won't include the necessary Tailwind base styles or custom configurations correctly.

The `globals.css` file I provided contains the *source* configuration (Tailwind directives, custom styles using `@apply`), not the final *output* CSS.

## 6. Troubleshooting Missing CSS in Vercel

If styles are missing after deploying to Vercel:

1.  **Check Build Logs**: Look for any errors related to Tailwind, PostCSS, or CSS processing in the Vercel deployment logs.
2.  **Verify File Structure**: Ensure `tailwind.config.js`, `package.json`, and the `src` directory (containing `globals.css`) are all present in the root of your GitHub repository.
3.  **Verify `tailwind.config.js`**: Double-check the `content` paths in `tailwind.config.js` to make sure they correctly point to your component and page files.
4.  **Verify `globals.css` Import**: Ensure `import "./globals.css";` is present in your `src/app/layout.tsx` file.
5.  **Check Vercel Framework Preset**: Make sure Vercel correctly detected your project as "Next.js".

By using the source files I recreated and ensuring the Vercel build settings are correct (as outlined in the Vercel deployment guide), the Tailwind CSS should build correctly, and your website should display with the intended light theme styles.
