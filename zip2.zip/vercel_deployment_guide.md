# Vercel Deployment Guide for Cybernack Next.js Website

This guide provides step-by-step instructions for deploying your Cybernack Next.js website from your GitHub repository to Vercel and connecting your custom domain (`cybernack.com`) managed via Wix.

**Prerequisites:**

*   You have uploaded the complete Next.js website source code (including `package.json`, `next.config.js`, `tailwind.config.js`, `src/` directory, etc.) to your public GitHub repository: `https://github.com/gireeshnr/gireeshnr-Cybernack_website`.
*   You have a Vercel account (sign up at [vercel.com](https://vercel.com/) if you don't have one, you can use your GitHub account).
*   You have access to your Wix account to manage DNS settings for `cybernack.com`.

## Step 1: Import Your Project to Vercel

1.  **Log in to Vercel**: Go to your Vercel dashboard ([vercel.com/dashboard](https://vercel.com/dashboard)).
2.  **Add New Project**: Click the "Add New..." button and select "Project".
3.  **Import Git Repository**: Vercel will prompt you to connect a Git provider. Select "Continue with GitHub".
4.  **Authorize Vercel**: If you haven't already, authorize Vercel to access your GitHub repositories.
5.  **Select Repository**: Find and select your `gireeshnr-Cybernack_website` repository. Click "Import".

## Step 2: Configure Your Project

Vercel is excellent at automatically detecting Next.js projects. Usually, you won't need to change much, but review these settings:

1.  **Framework Preset**: Ensure it's set to "Next.js".
2.  **Root Directory**: This should typically be the root of your repository (where `package.json` is located). Leave it as `./` unless your code is in a subdirectory.
3.  **Build and Output Settings**: Vercel usually overrides these automatically for Next.js. You generally don't need to set the Build Command (`npm run build`) or Output Directory (`.next`) manually, but verify they look correct if shown.
4.  **Environment Variables**: 
    *   Vercel typically uses recent Node.js versions by default. However, if you encounter Node version issues during the build, you can set a specific version here. Click "Environment Variables", add a variable with the key `NODE_VERSION` and value `18.x` or `20.x` (e.g., `18.17.0`).
5.  **Deploy**: Click the "Deploy" button.

Vercel will now clone your repository, install dependencies, build your Next.js application, and deploy it. You can monitor the build logs in real-time.

## Step 3: Preview Your Deployment

Once the deployment is complete, Vercel will provide you with a unique deployment URL (e.g., `cybernack-website-xxxxx.vercel.app`). Click on this URL or the site preview image to test your deployed website. Verify that all pages load correctly and the CSS styles are applied.

## Step 4: Connect Your Custom Domain (`cybernack.com`)

1.  **Go to Domains**: In your Vercel project dashboard, navigate to the "Settings" tab and then click "Domains".
2.  **Add Domain**: Enter `cybernack.com` in the input field and click "Add".
3.  **Choose Method**: Vercel will likely recommend adding it as the production domain. Confirm this.
4.  **Add `www` Redirect (Recommended)**: Vercel will usually ask if you want to add the `www.cybernack.com` domain as well and redirect it to the root domain (`cybernack.com`). It's generally recommended to do this. Select the redirect option.
5.  **View DNS Records**: Vercel will now show you the DNS records you need to configure in Wix. It will typically provide either:
    *   **A Record**: An IP address for the root domain (`@`).
    *   **CNAME Record**: A Vercel-specific URL for the `www` subdomain.
    *   **OR Nameservers**: Vercel might suggest changing your nameservers to Vercel's nameservers for easier management. **If you choose this option, Wix will no longer manage your DNS, and you'll need to re-configure your MX records for email within Vercel.** Using A/CNAME records is often simpler if you want to keep DNS management at Wix.

## Step 5: Configure DNS in Wix

1.  **Log in to Wix**: Access your Wix account and go to the Domains section.
2.  **Manage DNS**: Select `cybernack.com` and navigate to manage its DNS records (usually under "Advanced" or similar).
3.  **Update/Add Records (Based on Vercel's instructions)**:
    *   **If using A/CNAME Records:**
        *   **A Record**: Find the existing A record for `@` (or `cybernack.com`) and update its value (Points To) to the IP address provided by Vercel.
        *   **CNAME Record**: Find the existing CNAME record for `www` and update its value (Points To) to the Vercel URL provided (e.g., `cname.vercel-dns.com`). If no CNAME exists for `www`, add a new one.
    *   **If using Vercel Nameservers:**
        *   Find the section in Wix to change nameservers.
        *   Replace the existing Wix nameservers with the two nameservers provided by Vercel.
        *   **Important**: If you change nameservers, you MUST add your Zoho MX records within the Vercel DNS settings for your domain to ensure your `support@cybernack.com` email continues working.
4.  **Save Changes**: Save the DNS record changes in Wix.

## Step 6: Wait for DNS Propagation and Verify

1.  **Wait**: DNS changes can take anywhere from a few minutes to 48 hours to propagate globally.
2.  **Check Vercel**: Vercel's domain settings page will automatically check the DNS configuration and show when it's verified.
3.  **SSL Certificate**: Once verified, Vercel will automatically provision a free Let's Encrypt SSL certificate for your domain.
4.  **Test**: Visit `https://cybernack.com` and `https://www.cybernack.com` in your browser. Your website should load correctly and securely (with HTTPS).

Congratulations! Your Cybernack website should now be live on Vercel and accessible via your custom domain.
