# Cybernack Website Maintenance Guide (Vercel + GitHub)

This guide provides instructions on how to maintain and update your Cybernack Next.js website deployed on Vercel via your GitHub repository (`https://github.com/gireeshnr/gireeshnr-Cybernack_website`).

## 1. Making Content Updates

Most content updates (e.g., changing text on pages, updating feature descriptions) involve editing the `.tsx` files within the `src/app/` or `src/components/` directories in your GitHub repository.

1.  **Clone Repository**: If you don't have a local copy, clone your GitHub repository:
    ```bash
    git clone https://github.com/gireeshnr/gireeshnr-Cybernack_website.git
    cd gireeshnr-Cybernack_website
    ```
2.  **Make Changes**: Use a code editor (like VS Code) to modify the text or structure within the relevant `.tsx` files.
3.  **Commit Changes**: Stage and commit your changes using Git:
    ```bash
    git add .
    git commit -m "Update content on [Page Name] page"
    ```
4.  **Push Changes**: Push the changes back to your GitHub repository:
    ```bash
    git push origin main # Or your default branch name
    ```
5.  **Automatic Deployment**: Vercel is configured (by default) to automatically detect pushes to your main branch. It will trigger a new build and deploy the updated website. You can monitor the deployment progress in your Vercel dashboard.

## 2. Updating Styles (Tailwind CSS)

Style changes are primarily made using Tailwind utility classes directly in your `.tsx` files.

*   **Changing Existing Styles**: Modify the `className` attributes of HTML elements.
*   **Adding Custom Styles**: If needed, you can add custom base styles or component classes to `src/app/globals.css` using the `@layer` and `@apply` directives.
*   **Changing Theme**: To modify colors, fonts, or spacing, edit the `theme` section in `tailwind.config.js`.

After making style-related changes, commit and push to GitHub. Vercel will rebuild the site with the updated styles.

## 3. Updating Dependencies

Periodically, you should update the project's dependencies (Next.js, React, Tailwind, etc.) for security patches and new features.

1.  **Check for Updates**: In your local repository, run:
    ```bash
    npm outdated
    ```
2.  **Update Dependencies**: You can update them individually or use a tool like `npm-check-updates`:
    ```bash
    # Install npm-check-updates globally (if you haven't already)
    npm install -g npm-check-updates

    # Check for updates
    ncu

    # Update package.json
    ncu -u

    # Install updated packages
    npm install
    ```
3.  **Test Locally**: Before pushing, run the development server locally to ensure the updates haven't broken anything:
    ```bash
    npm run dev
    ```
    Test the website thoroughly in your browser.
4.  **Commit and Push**: If everything works, commit the updated `package.json` and `package-lock.json` files and push to GitHub. Vercel will deploy the changes.

## 4. Monitoring Your Deployment

*   **Vercel Dashboard**: Keep an eye on your Vercel project dashboard for deployment status, build logs, and any runtime errors.
*   **Analytics**: Vercel provides basic analytics (visits, bandwidth). You might want to integrate more detailed analytics like Google Analytics.
*   **Uptime Monitoring**: Consider using external uptime monitoring services (like UptimeRobot - free options available) to get notified if your site goes down.

## 5. Backups

Since your code is stored in GitHub, GitHub itself serves as your primary code backup. Vercel handles the deployment infrastructure.

*   **Code**: Regularly push changes to GitHub.
*   **Configuration**: Your Vercel settings (domain, environment variables) are stored in Vercel.
*   **Data**: This website is currently static content-focused. If you add features that store user data later (e.g., in a database), you will need to implement a separate backup strategy for that data.

By following these steps, you can effectively maintain and update your Cybernack website deployed on Vercel.
